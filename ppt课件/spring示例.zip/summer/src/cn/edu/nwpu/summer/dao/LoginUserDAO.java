/**
 * 
 */
package cn.edu.nwpu.summer.dao;

import cn.edu.nwpu.summer.entity.LoginUser;

/**
 * @author wben 2014年10月28日-下午12:01:07
 *
 */
public interface LoginUserDAO extends AbstractDAO<LoginUser, Long> {

}
