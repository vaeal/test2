/**
 * 
 */
package cn.edu.nwpu.summer.form;

/**
 * @author wben 2014年10月28日-上午11:38:03
 *
 */
public class LoginForm {

	private String loginName;

	private String password;

	/**
	 * @return the loginName
	 */
	public String getLoginName() {
		return loginName;
	}

	/**
	 * @param loginName
	 *            the loginName to set
	 */
	public void setLoginName(String loginName) {
		this.loginName = loginName;
	}

	/**
	 * @return the password
	 */
	public String getPassword() {
		return password;
	}

	/**
	 * @param password
	 *            the password to set
	 */
	public void setPassword(String password) {
		this.password = password;
	}

}
