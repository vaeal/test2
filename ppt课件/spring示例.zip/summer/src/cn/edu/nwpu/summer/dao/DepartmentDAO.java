/**
 * 
 */
package cn.edu.nwpu.summer.dao;

import cn.edu.nwpu.summer.entity.Department;

/**
 * @author wben 2014年10月30日-下午1:23:23
 *
 */
public interface DepartmentDAO extends AbstractDAO<Department, Long> {

}
